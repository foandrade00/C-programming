// contactInfo.cpp -- This program prints information about the programmer.
#include <iostream>
using namespace std;

int main()
{   
   // WRITE A cout STATEMENT TO PRINT YOUR FIRST AND LAST NAME, 
   // FOLLOWED BY A BLANK LINE.
   // WRITE A cout STATEMENT TO PRINT YOUR PREFERRED PHONE NUMBER.
   // WRITE A cout STATEMENT TO PRINT YOUR PREFERRED EMAIL ADDRESS.
   
   return 0;
}
