// Lab 2 tryIt2B -- Using endl and \n
#include <iostream>
using namespace std;

int main()
{  
	cout << "tryIt2B" << '\n';
   cout << "Hello " << "endl";
	cout << "Hello " << endl;
   cout << "Hello /n";
   cout << "Hello \\n";
   cout << "Hello \n";
    
   return 0;
}
