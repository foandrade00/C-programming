// Ortiz
//Fabian
//ITI 2410 C++ Fall 2020
// October 21,2020
// contactInfo.cpp -- This program prints information about the programmer.
#include <iostream>
using namespace std;

int main()

{   
   // WRITE A cout STATEMENT TO PRINT YOUR FIRST AND LAST NAME, 
   cout<< "Fabian Ortiz Andrade"<< endl ;
   
   // FOLLOWED BY A BLANK LINE.
   
   // WRITE A cout STATEMENT TO PRINT YOUR PREFERRED PHONE NUMBER.
   cout<< "6154388171"<< endl;
   
   // WRITE A cout STATEMENT TO PRINT YOUR PREFERRED EMAIL ADDRESS.
   cout<< "foandrade00@gmail.com"<< endl;
   return 0;
}
